from shadecreed.core.utils.base import home_dir,stream_dir

home_dir.mkdir(parents=True, exist_ok=True)
stream_dir.mkdir(parents=True,exist_ok=True)